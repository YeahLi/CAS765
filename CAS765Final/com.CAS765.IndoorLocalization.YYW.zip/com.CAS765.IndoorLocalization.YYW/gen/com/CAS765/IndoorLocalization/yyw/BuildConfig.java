/** Automatically generated file. DO NOT MODIFY */
package com.CAS765.IndoorLocalization.yyw;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}