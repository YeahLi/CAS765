package com.CAS765.IndoorLocalization.yyw;

public class LowPassFIR {
	double ALPHA = 0;
	 int N = 16;
	 double[] Prior = new double[N];
	
	LowPassFIR(double d) {
		this.ALPHA = d;
		for(int i = 0; i < N; i++){
			Prior[i] = Double.NaN;//Not a Number
		}
	}
	
	double transform(double input){
		double output;
		if(Double.isNaN(Prior[1])){
			output = input;
		}
		else
			output = Prior[1] + this.ALPHA*(input - Prior[1]);
		Prior[1] = output;
		return output;
	}
		
	double integrate(double input) {
		double output;
		
		for( int i = N - 1; i >= 0; i--)
		{
			if(Double.isNaN(Prior[i])){
				output = input;
				Prior[i] = input;
				return output;
			}
		}
		output = (1.0/(N+1)) * (input + new Tools().sum(Prior));
		for( int i = N - 2; i >= 0; i--){
			Prior[i+1] = Prior[i];
		}
		Prior[0] = input;
		return output;
	}
}
