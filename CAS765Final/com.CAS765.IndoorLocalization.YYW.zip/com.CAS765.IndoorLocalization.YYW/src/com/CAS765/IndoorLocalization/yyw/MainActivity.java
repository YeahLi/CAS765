package com.CAS765.IndoorLocalization.yyw;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import android.graphics.Paint;
import android.graphics.Point;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.AssetManager;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements SensorEventListener{
	private final int SAMPLING_RATE = 50;//Hz
	private Button mStartButton, mResetButton,mWifi;
	private TextView mStepNumber, mMoveLength,mAzimuth, lengthtext;
	private MyImageView map;
	private SensorManager mSensorManager;
	private Sensor mAccelerometer, mCompass;
	private int mSensorSamplingRate = 1000000/SAMPLING_RATE;//SensorManager.SENSOR_DELAY_GAME
	private boolean isStarted = false,wifistarted =false;
	private StepCount stepCount;
	private Position position = new Position(0,0);
	private Paint paint = new Paint();
	private ArrayList<ArrayList<Info>> Table= new ArrayList<ArrayList<Info>>();
	private ArrayList<Point> pTable= new ArrayList<Point>();
	private ArrayList<Data> dTable= new ArrayList<Data>();
	private WifiManager mWifiManager;
	private WifiReceiver mReceiverWifi;
	private Match match;
	private Point point;
	private Boolean version= false;
	private AssetManager assetManager;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

		// Initialize the views
		mStartButton = (Button) findViewById(R.id.buttonStart);
		mWifi= (Button) findViewById(R.id.button1);
		mStartButton.setEnabled(false);	
		mStepNumber=(TextView) findViewById(R.id.stepNumber);
		mMoveLength=(TextView) findViewById(R.id.moveLength);
		mAzimuth=(TextView) findViewById(R.id.azimuth);
		lengthtext=(TextView) findViewById(R.id.textView4);
		map=(MyImageView) findViewById(R.id.imageView1);
		// views if the sensor is not available
		mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		//StepCount
		stepCount=new StepCount();
			
		//read asset files
		assetManager = getAssets();	
		String[] files=null;
		String data=null;
		try {
			files = assetManager.list("wifi");
			for(int i=0;i<files.length;i++){
				String filePath="wifi/"+files[i];
				InputStreamReader inputReader = new InputStreamReader(assetManager.open(filePath));
				BufferedReader bufReader = new BufferedReader(inputReader);
				
				ArrayList<Info> table=new ArrayList<Info>();
				String strLine;	
				String s[]=files[i].split(" ");
		    	if(s.length==2)
		    	{
		    		pTable.add(new Point(Integer.parseInt(s[0]),Integer.parseInt(s[1])));
		    	}
		    	while ((strLine = bufReader.readLine()) != null){		    		
		    		String str[]=strLine.split("\t");
		    		if(str.length==3)
		    		{	    			
		    			Info info= new Info(str[0]);
			    		info.setHighestlevel(Integer.parseInt(str[1]));
			    		info.setLowestlevel(Integer.parseInt(str[2]));	
			    		table.add(info);
		    		}
		    	}
		    	Table.add(table);
		    	inputReader.close();
			}
			match=new Match(Table);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_LONG).show();
		}
		
		AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
		 builder1.setMessage("Choose the Version you want to use");
		 builder1.setTitle("Version");
		 builder1.setPositiveButton("Wifi(Recommended)", new DialogInterface.OnClickListener() {
			 public void onClick(DialogInterface dialog, int id) { 
				 mStartButton.setEnabled(false);
				 version= false;
				 startWiFi();
	             dialog.dismiss();  
	         }
		 });
		 builder1.setNegativeButton("Step Detector", new DialogInterface.OnClickListener(){
			 public void onClick(DialogInterface dialog, int id) { 
				 //mStartButton.setEnabled(false);
				 version =true;
	             dialog.dismiss();  
	         }
		 });
		 builder1.create().show();
		
		// get sensors
		
		if ((mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)) == null) 
		{
			 AlertDialog.Builder builder = new AlertDialog.Builder(this);
			 builder.setMessage("The Accelerometer Sensor is unusable!");
			 builder.setTitle("Alert");
			 builder.setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
				 public void onClick(DialogInterface dialog, int id) { 
					 mStartButton.setEnabled(false);
		             dialog.dismiss();  
		         }
			 });
			 builder.create().show();
		}

		if ((mCompass = mSensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION/*TYPE_MAGNETIC_FIELD*/)) == null) {
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			 builder.setMessage("The Compass Sensor is unusable!");
			 builder.setTitle("Alert");
			 builder.setPositiveButton("Got it!", new DialogInterface.OnClickListener() {
				 public void onClick(DialogInterface dialog, int id) { 
					 mStartButton.setEnabled(false);
		             dialog.dismiss();  
		         }
			 });
			 builder.create().show();
		}
		
		mWifi.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!wifistarted) {
					startWiFi();					
				}
			}
		});	
		
		mStartButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!isStarted) {
					mStartButton.setText("Stop");
					startSensors();									
					isStarted = true;
					//initialize position using WiFi
					
				} else {
					mStartButton.setText("Start");
					stopAll();
					isStarted = false;
				}
			}
		});		
		
		mResetButton = (Button) findViewById(R.id.buttonReset);
		mResetButton.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				resetAll();
			}
		});
	}
	
	class WifiReceiver extends BroadcastReceiver {		
		public void onReceive(Context c, Intent intent) {			
			List<ScanResult> wifiList = mWifiManager.getScanResults();
			dTable = new ArrayList<Data>();
			for(ScanResult sr:wifiList)
			{
				Data data= new Data(sr.BSSID,sr.level);
	    		int flag=0;
	    		
	    		for(Data d: dTable){
	    			if(d.getBSSID().equals(data.getBSSID())){
	    				flag=1;
	    			}
	    		}
	    			
	    		if(flag==0){
	    			dTable.add(data);
	    		}	    							
			}
			float p[]=match.match(dTable);
			float r=0;
			for(float i:p){
				if(i>r){
					r=i;
				}
			}
			int pos = match.compare(p);
			if(pos!=-1){
				point= new Point(pTable.get(pos).x,pTable.get(pos).y);
				map.cleanpath();
				Toast.makeText(MainActivity.this, "Wifi Correction "+r+"%", Toast.LENGTH_SHORT).show();
				position=new Position((double)point.x,(double)point.y);
				map.setPoint(point);
				map.invalidate();
				if(mStartButton.isEnabled()== false && version==true){
					mStartButton.setEnabled(true);
				}
			}
			else{
				Toast.makeText(MainActivity.this, "Please go inside the building", Toast.LENGTH_SHORT).show();
			}
			if(version==false){
				mWifiManager.startScan();
			}			
		}
	}
	
	void startWiFi() {
		mWifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
		mReceiverWifi=new WifiReceiver();
		registerReceiver(mReceiverWifi, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
		mWifiManager.startScan();		
	}
	
	void startSensors() {
		// register the listener for accelerometer
		mSensorManager.registerListener(this, mAccelerometer,mSensorSamplingRate);
		//register the listener for gyro
		//mSensorManager.registerListener(this, mGyro,mSensorSamplingRate);
		//register the listener for compass
		mSensorManager.registerListener(this, mCompass,mSensorSamplingRate);
		//Unable Reset Button
		mResetButton.setEnabled(false);		
	}
	//Upon stopping the sensors, 
	void stopAll() {
		mResetButton.setEnabled(true);
		//unregister the sensor listener if exists
		mSensorManager.unregisterListener(this);		
		if (mReceiverWifi != null)
		{
			unregisterReceiver(mReceiverWifi);
		}
	}
	void resetAll() {
		mStepNumber.setText("0");
		mMoveLength.setText("0");
		mAzimuth.setText("0");
		stepCount.setStepCount(0);
		stepCount.setMoveLength(0);
		stepCount.setAzimuth(0);
		lengthtext.setText("0");
		position.set(0, 0);
		map.cleanpath();
		map.invalidate();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {
		// TODO Auto-generated method stub
		
	}
	
	// Handling sensor reading changes
	@Override
	public void onSensorChanged(SensorEvent event) {
		SensorReading acc, gyro, comp;
		if (event.sensor == mAccelerometer) {
			acc=new SensorReading("acc",event.timestamp,event.values);
			stepCount.countSteps(acc);
			if(stepCount.getStepCount()!=Integer.parseInt((String) mStepNumber.getText())){
				mStepNumber.setText(String.valueOf(stepCount.getStepCount()));			
				BigDecimal bd=new BigDecimal(stepCount.getMoveLength());   
		    	bd = bd.setScale(2,BigDecimal.ROUND_HALF_UP);
				mMoveLength.setText(String.valueOf(bd));
				BigDecimal bd1=new BigDecimal(stepCount.getAzimuth());   
		    	bd1 = bd1.setScale(2,BigDecimal.ROUND_HALF_UP);
				mAzimuth.setText(String.valueOf(bd1));
				double SL=stepCount.getMoveLength();
				double azimuth=stepCount.getAzimuth();
				double northSL=0;
				double eastSL=0;
				
//				azimuth = azimuth-25;
//				if(azimuth<= 0)
//				{
//					azimuth=360+azimuth;
//				}
				
				
				if(azimuth>=0.0&&azimuth<=90){					
				    northSL=(-1)*Math.cos(azimuth*Math.PI/180)*SL;
				    eastSL=Math.sin(azimuth*Math.PI/180)*SL;
				}
				if(azimuth>90&&azimuth<=180){
					azimuth=azimuth-90;
				    northSL=Math.sin(azimuth*Math.PI/180)*SL;
				    eastSL=Math.cos(azimuth*Math.PI/180)*SL;
				}
				if(azimuth>180&&azimuth<=270){
					azimuth=azimuth-180;
				    northSL=Math.cos(azimuth*Math.PI/180)*SL;
				    eastSL=(-1)*Math.sin(azimuth*Math.PI/180)*SL;
				}
				if(azimuth>270&&azimuth<360){
					azimuth=azimuth-270;
				    northSL=(-1)*Math.sin(azimuth*Math.PI/180)*SL;
				    eastSL=(-1)*Math.cos(azimuth*Math.PI/180)*SL;
				}
				
				//draw position on the map
				double x=position.getX()+(eastSL*7);
				double y=position.getY()+(northSL*7);
				position.set(x, y);
				lengthtext.setText((int)(x+0.5)+","+(int)(y+0.5));
				map.setPoint(new Point((int)(x+0.5),(int)(y+0.5)));
				map.invalidate();
			}
	    }
		if (event.sensor == mCompass) {
			comp=new SensorReading("compass",event.timestamp,event.values);
			stepCount.setDegree(event.values[0]);
		}
	}
}
