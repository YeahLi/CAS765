package com.CAS765.IndoorLocalization.yyw;
import java.util.ArrayList;


public class Match {
	private ArrayList<ArrayList<Info>> Table= new ArrayList<ArrayList<Info>>();
	
	public Match(ArrayList<ArrayList<Info>> t){
		Table=t;
	}
	
	public float[] match(ArrayList<Data> dtable){
		int[] result=new int[Table.size()];
		float[] r= new float[Table.size()];
		for(ArrayList<Info> table:Table){
			for(Data d:dtable){
				for(Info i:table){
					if(i.getBSSID().equals(d.getBSSID())){
						if(d.getLevel()<i.getHighestlevel()&&d.getLevel()>i.getLowestlevel()){
							result[Table.indexOf(table)]++;
						}						
					}
				}
			}
			r[Table.indexOf(table)]=((float)result[Table.indexOf(table)]/(float)table.size())*100;
		}		
		return r;		
	}
	
	public int compare(float[] list){
		float result=0;
		int pos=-1;
		for(int i=0; i<list.length;i++){
			if(list[i]>result){
				result=list[i];
				pos=i;
			}
		}
		return pos;
	}
}
