package com.CAS765.IndoorLocalization.yyw;

public class Data {
	private String BSSID;
	private int level;
	
	public Data(String bssid,int level){
		this.BSSID=bssid;
		this.level=level;
	}

	public String getBSSID() {
		return BSSID;
	}

	public void setBSSID(String bSSID) {
		BSSID = bSSID;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}	
}
