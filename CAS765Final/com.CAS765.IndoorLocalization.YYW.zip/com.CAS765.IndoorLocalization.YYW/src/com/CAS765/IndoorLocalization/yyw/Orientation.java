package com.CAS765.IndoorLocalization.yyw;

public class Orientation {
	private double azimuth;
	int times=0;
	double[] datalist=new double[16];
	double degreeFilter=0;
	double degreeFinal=0;
	boolean mInitialized=false;
	final double alpha = 0.3;
	public Orientation()
	{
		for(int i=0;i<datalist.length;i++)
		{
			datalist[i]=Double.NaN;
		}
	}
	public void calculateAzimuth(double degree)
	{
		if(!mInitialized){
			degreeFilter=degree;
			//mInitialized=true;
		}else{
			degreeFilter=alpha*degree+(1-alpha)*degreeFilter;
		}
		//degreeFinal=degreeFilter;
		if(!mInitialized){
			mInitialized=true;
			degreeFinal=degreeFilter;
		}else{
			degreeFinal=(16*degreeFinal+degreeFilter)/17;
		}
		int count=times%16;
		times++;
		datalist[count]=degreeFinal;
		double total=0;
		double num=0;
		for(int i=0;i<datalist.length;i++)
		{
			if(datalist[i]!=Double.NaN)
			{
				total=total+datalist[i];
				num++;
			}
		}
		azimuth=total/num;
	}
	public double getAzimuth() {
		return azimuth;
	}
	public void setAzimuth(double azimuth) {
		this.azimuth = azimuth;
	}
}
