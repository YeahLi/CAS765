package com.CAS765.IndoorLocalization.yyw;

public class Info {
	private String BSSID;
	private int highestlevel;
	private int lowestlevel;
	
	public Info(String bssid){
		this.BSSID=bssid;
		highestlevel=0;
		lowestlevel=0;
	}
	
	public void setlevel(int level){
		if(level>highestlevel){
			highestlevel=level;
		}
		if(level<lowestlevel){
			lowestlevel=level;
		}			
	}	
	
	public String getBSSID() {
		return BSSID;
	}
	public void setBSSID(String bSSID) {
		BSSID = bSSID;
	}
	public int getHighestlevel() {
		return highestlevel;
	}
	public void setHighestlevel(int highestlevel) {
		this.highestlevel = highestlevel;
	}
	public int getLowestlevel() {
		return lowestlevel;
	}
	public void setLowestlevel(int lowestlevel) {
		this.lowestlevel = lowestlevel;
	}
	
	
	
}
