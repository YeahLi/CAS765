package com.CAS765.IndoorLocalization.yyw;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.AttributeSet;
import android.widget.ImageView;

public class MyImageView extends ImageView
{
	Paint paint = new Paint();
	Point point = new Point(10,10);
	ArrayList<Point> points = new ArrayList<Point>();
	public MyImageView(Context context) {
		super(context);
		paint.setColor(Color.RED);
		paint.setStrokeWidth(2); 
	}

	public MyImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
		paint.setColor(Color.RED);
		paint.setStrokeWidth(2); 
    }
	
	public void setPoint(Point p){
		point = p;
		points.add(point);
	}
	
	public void cleanpath()
	{
		points= new ArrayList<Point>();
	}

	@Override
    protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		for(Point p: points){
			canvas.drawCircle(p.x, p.y, 5, paint);
		}		
    }
	
}